//#include "nn.h"
//
//
//NN::~NN() {
//}
//
//int NN::get_frame_len() {
//  return frame_len;
//}
//
//int NN::get_frame_shift() {
//  return frame_shift;
//}
//
//int NN::get_num_mfcc_features() {
//  return num_mfcc_features;
//}
//
//int NN::get_num_frames() {
//  return num_frames;
//}
//
//int NN::get_num_out_classes() {
//  return num_out_classes;
//}
//
//int NN::get_in_dec_bits() {
//  return in_dec_bits;
//}
//
